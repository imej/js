'use strict';

/* Controllers */

var pcdControllers = angular.module('pcdControllers', []);

pcdControllers.controller('JobListCtrl', ['$scope', 
  function($scope) {
      $scope.jobs = 'This is the jobs list';
  }]);

pcdControllers.controller('JobDetailCtrl', ['$scope', '$routeParams',
    function($scope, $routeParams) {
        $scope.job = {
            Name: 'myjob',
            Id: $routeParams.jobId        
        };
  }]);

pcdControllers.controller('CostCodeBookCtrl', ['$scope', 'CostCodeBook',
  function($scope, CostCodeBook) {
      $scope.costCodes = CostCodeBook.query();
  }]);

pcdControllers.controller('CostCodeBookDetailCtrl', ['$scope', '$routeParams',
  function($scope, $routeParams) {
      $scope.costCodeBookDetail = {id: $routeParams.costCodeBookId};
  }]);

