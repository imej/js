'use strict';

/* Services */
var pcdServices = angular.module('pcdServices', ['ngResource']);

pcdServices.factory('CostCodeBook', ['$resource', function($resource) {
    return $resource('data/:costCodeId.json', {}, {
    	query: {method: 'GET', params: {costCodeId: 'cost-code-book'}, isArray: true}
    });	
}]);