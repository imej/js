'use strict';

/* App Module */

var pcdApp = angular.module('pcdApp', [
    'ngRoute',
    'pcdControllers',
    'pcdServices'
]);

pcdApp.config(['$routeProvider',
               function ($routeProvider) {
                   $routeProvider.
                   when('/', {
                       templateUrl: 'partials/job-list.html',
                       controller: 'JobListCtrl'
                   }).
                   when('/jobs/:jobId', {
                       templateUrl: 'partials/job-detail.html',
                       controller: 'JobDetailCtrl'
                   }).
                   when('/cost-code-book', {
                       templateUrl: 'partials/cost-code-book-list.html',
                       controller: 'CostCodeBookCtrl'
                   }).
                   when('/cost-code-book/:costCodeBookId', {
                       templateUrl: 'partials/cost-code-book-detail.html',
                       controller: 'CostCodeBookDetailCtrl'
                   }).
                   otherwise({
                       redirectTo: '/'
                   });
               }]);